module.exports = async client => {
    console.log(`A bot ${client.user.tag} de id ${client.user.id}, foi iniciada corretamente com seu sistema de login`);
    setInterval(function () {
      var tabela = [
        { name: `zLuuiza ©️ 2021`, type: "PLAYING" }
      ]
      let activity = tabela[Math.floor(Math.random() * tabela.length)];
      client.user.setActivity(activity)
    }, 10000)
}