const Discord = require('discord.js')
module.exports.run = (client, message, args) =>{
    message.delete();
    if(!message.member.permissions.has("ADMINISTRATOR")) return message.channel.send(`você não tem permissão para usar este comando  de admin`).then(msg => msg.delete({timeout: 5000}))
    let cor = '#00FFFF'
    let avatar = message.author.displayAvatarURL({ dynamic: true, format: "png"})
    let tipo = args[0]
    let chat = args.slice(1).join(' ')
    if(tipo == 'voice'){
        
        message.guild.channels.create(chat, {type: `${tipo}`})
        const embed = new Discord.MessageEmbed()
        .setColor(cor)
        .setTitle('**novo chat voz**')
        .setDescription(`*nome do chat criado*: **${chat}** \n *tipo de chat* : **${tipo}** \n criador: ${client.user.username} \n expedidor: ${message.author}`)
        .setThumbnail(avatar)
        .setTimestamp()
        message.channel.send(embed)
       
    }else if(tipo == "text"){
        
        message.guild.channels.create(chat, {type: `${tipo}`})
        const embed = new Discord.MessageEmbed()
        .setColor(cor)
        .setTitle('**novo chat texto**')
        .setDescription(`*nome do chat criado*: **${chat}** \n *tipo de chat* : **${tipo}** \n criador: ${client.user.username} \n expedidor: ${message.author}`)
        .setThumbnail(avatar)
        .setTimestamp()
        message.channel.send(embed)
        
    }else{
        message.channel.send(`primeiro selecione tipo de chat(voice ou text) depois nome chat`).then(msg => msg.delete({timeout: 5000}))
    }
    }
    