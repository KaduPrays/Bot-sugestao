const Discord = require("discord.js")

module.exports.run = async (bot,message,args) => {
    const sugestao = args.join(" ")
    const channel = bot.channels.cache.get("843690074519371796")

    if(!sugestao) {
        return message.channel.send("Coloque alguma sugestão!")
    }

    message.delete();
    const embed = new Discord.MessageEmbed()
    .setTitle("Nova sugestão!")
    .setThumbnail(message.author.displayAvatarURL())
    .setColor("#00FFFF")
    .addField("Nome do usuário", message.author.username)
    .addField("Sugestão", sugestao)
    await channel.send(embed).then(msg => {
        msg.react(`<:verificado:837064856209063957>`),
        msg.react(`<:negativo:837064922008911903>`)
    })
}

module.exports.help = {
    name: "sugerir",
    aliases: ["sugestão"]
}